# Nextor Native NFC-e Engine — full archived snapshot

Archived: 2026-10-02
Archived head: 8751561de7bfc4893d2644fb9afa0e459239e4b3
Baseline before engine: 244efe670c3f1da7d13c5c4f3e98d309bf968e1d

This archive contains the full source snapshot of the retired native NFC-e engine:
- app/Fiscal/*
- official fiscal resources/schemas used by the engine
- SEFAZ endpoint catalog
- fiscal documentation
- fiscal tests and fixtures
- fiscal migrations 000004..000007
- fiscal status Artisan command and CI workflow
- shared-file snapshots under snapshot/shared/

The active Nextor application no longer loads this engine.

The engine was retired before production use. No real PFX, private key, certificate password, CSC or production credential is included.

Exact Git history is also preserved in repository commit 8751561de7bfc4893d2644fb9afa0e459239e4b3.
