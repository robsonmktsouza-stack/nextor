# Nextor Native NFC-e Engine — archived

Archived on 2026-10-02.

This ZIP preserves the proprietary/native NFC-e engine that was developed inside Nextor and then retired before production use.

Archived repository head:
8751561de7bfc4893d2644fb9afa0e459239e4b3

Baseline before the native fiscal engine:
244efe670c3f1da7d13c5c4f3e98d309bf968e1d

The active application no longer loads or uses this engine.

Contents:
- compare.json: GitHub comparison from the pre-engine baseline to the archived head, including commit/file metadata and patches supplied by GitHub.
- MANIFEST.txt: file list from that comparison.
- snapshot/: full snapshots of shared files useful when reconstructing the retired implementation.

The exact full source remains recoverable from Git history at commit:
8751561de7bfc4893d2644fb9afa0e459239e4b3

No real PFX, certificate password, private key, CSC or production credential is included.
