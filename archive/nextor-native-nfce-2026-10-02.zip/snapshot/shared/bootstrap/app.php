<?php

use App\Console\Commands\FiscalSefazStatusCommand;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withCommands([
        FiscalSefazStatusCommand::class,
    ])
    ->withMiddleware(function (Middleware $middleware): void {
        // Laravel web middleware includes sessions, CSRF, auth and signed cookies.
    })
    ->withExceptions(function (Exceptions $exceptions): void {
    })->create();
